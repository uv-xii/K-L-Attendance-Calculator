// popup.js
const CALC_URL = 'https://klu-attendance.in';
const W = {L:100, P:50, T:25, S:25};
const $ = id => document.getElementById(id);

function calcPct(s) {
  let wa=0, wt=0;
  if(s.hasL && s.L[1]>0){ wa+=s.L[0]*W.L; wt+=s.L[1]*W.L; }
  if(s.hasP && s.P[1]>0){ wa+=s.P[0]*W.P; wt+=s.P[1]*W.P; }
  if(s.hasT && s.T[1]>0){ wa+=s.T[0]*W.T; wt+=s.T[1]*W.T; }
  if(s.hasS && s.S[1]>0){ wa+=s.S[0]*W.S; wt+=s.S[1]*W.S; }
  return wt===0 ? null : Math.round(wa/wt*10000)/100;
}
function pctCls(v){ return v===null?'':v>=75?'pct-safe':v>=65?'pct-warn':'pct-dng'; }
function setStatus(d,t,desc){ $('statusDot').className='status-dot '+d; $('statusTitle').textContent=t; $('statusDesc').textContent=desc; }
function showError(m){ $('errorBox').textContent=m; $('errorBox').style.display='block'; }
function hideError(){ $('errorBox').style.display='none'; }

function renderPreview(subjects) {
  const el = $('preview');
  if(!subjects||!subjects.length){ el.classList.remove('show'); return; }
  el.innerHTML = subjects.map(s=>{
    const p=calcPct(s),cls=pctCls(p);
    const name=s.name.length>28?s.name.substring(0,26)+'…':s.name;
    return `<div class="prev-row"><span class="prev-name">${name}</span><span class="prev-pct ${cls}">${p!==null?p+'%':'—'}</span></div>`;
  }).join('');
  el.classList.add('show');
}

// Scraper — runs inside ERP tab
function scrapeAttendancePage() {
  const subjectMap = {};
  let targetTable = null;
  document.querySelectorAll('table').forEach(t=>{
    if((t.innerText||'').toLowerCase().includes('total conducted')) targetTable=t;
  });
  if(!targetTable) return [];
  const headers=Array.from(targetTable.querySelectorAll('th')).map(h=>h.innerText.trim().toLowerCase());
  const find=keys=>{for(let i=0;i<headers.length;i++)if(keys.some(k=>headers[i].includes(k)))return i;return -1;};
  const col={
    desc: find(['coursedesc','subject name','course name']),
    ltps: find(['ltps','type','l/t/p/s','ltp']),
    conducted: find(['total conducted','conducted']),
    attended:  find(['total attended','attended']),
  };
  targetTable.querySelectorAll('tr').forEach(row=>{
    const cells=row.querySelectorAll('td');
    if(cells.length<4) return;
    const get=i=>(i>=0&&cells[i])?cells[i].innerText.trim():'';
    const name=get(col.desc), ltps=get(col.ltps).toUpperCase().replace(/\s/g,'');
    const conducted=parseInt(get(col.conducted))||0, attended=parseInt(get(col.attended))||0;
    if(!name||!ltps||conducted===0) return;
    if(!['L','T','P','S'].includes(ltps)) return;
    if(!subjectMap[name]) subjectMap[name]={name,L:[0,0],T:[0,0],P:[0,0],S:[0,0],hasL:false,hasT:false,hasP:false,hasS:false};
    subjectMap[name][ltps]=[attended,conducted];
    subjectMap[name]['has'+ltps]=true;
  });
  return Object.values(subjectMap);
}

let scrapedSubjects = null;

async function init() {
  const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
  if(!tab) return;
  if(!tab.url.includes('newerp.kluniversity.in')) {
    setStatus('dot-idle','Not on ERP page','Open newerp.kluniversity.in → Attendance Register.');
    $('syncBtn').disabled=true; $('syncLabel').textContent='Open ERP first';
    $('hintText').innerHTML=`<div class="steps">
      <div class="step-row"><div class="step-num">1</div><div class="step-txt">Go to newerp.kluniversity.in</div></div>
      <div class="step-row"><div class="step-num">2</div><div class="step-txt">Log in → <strong style="color:#e2e6f3">Attendance Register</strong></div></div>
      <div class="step-row"><div class="step-num">3</div><div class="step-txt">Select year & semester → press <strong style="color:#e2e6f3">Search</strong></div></div>
      <div class="step-row"><div class="step-num">4</div><div class="step-txt">Come back here → <strong style="color:#5b52ff">Send to Calculator</strong></div></div>
    </div>`;
    return;
  }
  setStatus('dot-warn','Reading attendance…','Scanning your attendance table…');
  $('syncBtn').disabled=true; $('syncLabel').textContent='Reading…'; $('spinner').style.display='block';
  try {
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeAttendancePage});
    $('spinner').style.display='none';
    const subjects=results[0]?.result;
    if(!subjects||!subjects.length){
      setStatus('dot-warn','No data found','Make sure you pressed Search on the attendance page.');
      $('syncLabel').textContent='No data found'; $('syncBtn').disabled=true;
      $('hintText').textContent='Select Academic Year & Semester → press Search → try again.';
      return;
    }
    scrapedSubjects=subjects;
    setStatus('dot-ok',subjects.length+' subjects found ✓','Ready to send to your calculator.');
    $('syncBtn').disabled=false; $('syncLabel').textContent='Send to Calculator ⚡';
    $('hintText').textContent='Click the button to auto-fill all subjects instantly.';
    renderPreview(subjects);
  } catch(err) {
    $('spinner').style.display='none';
    setStatus('dot-idle','Could not read page','Make sure you are on the attendance page.');
    showError('Error: '+err.message);
    $('syncLabel').textContent='Retry'; $('syncBtn').disabled=false; $('syncBtn').onclick=init;
  }
}

async function sendToCalculator() {
  if(!scrapedSubjects||!scrapedSubjects.length) return;
  hideError();
  $('spinner').style.display='block'; $('syncLabel').textContent='Opening…'; $('syncBtn').disabled=true;
  try {
    // Encode subjects as base64 in URL hash — no scripting into calculator needed
    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(scrapedSubjects))));
    const url = CALC_URL + '#erp=' + encoded;
    await chrome.tabs.create({ url });
    $('spinner').style.display='none'; $('syncLabel').textContent='✓ Opened!';
    setStatus('dot-ok','Done! 🎉',scrapedSubjects.length+' subjects sent to calculator.');
    setTimeout(()=>{ $('syncLabel').textContent='Send to Calculator ⚡'; $('syncBtn').disabled=false; },2500);
  } catch(err) {
    $('spinner').style.display='none';
    showError('Failed: '+err.message);
    $('syncLabel').textContent='Send to Calculator ⚡'; $('syncBtn').disabled=false;
  }
}

$('syncBtn').addEventListener('click', sendToCalculator);
$('openCalcBtn').addEventListener('click', ()=>chrome.tabs.create({url:CALC_URL}));
init();
