// content.js — runs on newerp.kluniversity.in
// Scrapes attendance and sends via URL to calculator

(function () {
  const CALC_URL = 'https://klu-attendance.in';
  if (document.getElementById('klu-calc-btn')) return;

  // ── Floating button ───────────────────────────────
  const btn = document.createElement('button');
  btn.id = 'klu-calc-btn';
  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style="flex-shrink:0">
      <rect x="1" y="1" width="14" height="14" rx="3" stroke="white" stroke-width="1.4"/>
      <path d="M4 5h4M4 8h6M4 11h4" stroke="white" stroke-width="1.3" stroke-linecap="round"/>
      <circle cx="12" cy="4.5" r="1.2" fill="white"/>
    </svg>
    <span>Send to Calculator</span>`;

  btn.style.cssText = `
    position:fixed; bottom:28px; right:28px; z-index:999999;
    display:flex; align-items:center; gap:8px;
    background:#5b52ff; color:#fff; border:none; border-radius:100px;
    padding:12px 20px; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    font-size:13px; font-weight:600; cursor:pointer;
    box-shadow:0 4px 20px rgba(91,82,255,0.5);
    transition:transform 0.2s, background 0.2s;`;

  btn.onmouseenter = () => { btn.style.background='#7068ff'; btn.style.transform='translateY(-2px)'; };
  btn.onmouseleave = () => { btn.style.background='#5b52ff'; btn.style.transform='translateY(0)'; };

  btn.onclick = () => {
    const subjects = scrape();
    if (!subjects.length) {
      showToast('No data found. Press Search first!', 'error');
      return;
    }
    // Encode data as base64 in URL hash
    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(subjects))));
    const url = CALC_URL + '#erp=' + encoded;
    window.open(url, '_blank');
    showToast('✓ Opening calculator with ' + subjects.length + ' subjects!', 'success');
  };

  document.body.appendChild(btn);

  // ── Scraper ───────────────────────────────────────
  function scrape() {
    const subjectMap = {};
    let targetTable = null;

    document.querySelectorAll('table').forEach(t => {
      const txt = (t.innerText || '').toLowerCase();
      if (txt.includes('total conducted') || txt.includes('coursedesc')) targetTable = t;
    });
    if (!targetTable) return [];

    const headers = Array.from(targetTable.querySelectorAll('th')).map(h => h.innerText.trim().toLowerCase());
    const find = keys => { for (let i = 0; i < headers.length; i++) if (keys.some(k => headers[i].includes(k))) return i; return -1; };

    const col = {
      desc:      find(['coursedesc', 'subject name', 'course name']),
      ltps:      find(['ltps', 'type', 'l/t/p/s', 'ltp']),
      conducted: find(['total conducted', 'conducted']),
      attended:  find(['total attended', 'attended']),
    };

    targetTable.querySelectorAll('tr').forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length < 4) return;
      const get = i => (i >= 0 && cells[i]) ? cells[i].innerText.trim() : '';
      const name      = get(col.desc);
      const ltps      = get(col.ltps).toUpperCase().replace(/\s/g, '');
      const conducted = parseInt(get(col.conducted)) || 0;
      const attended  = parseInt(get(col.attended))  || 0;
      if (!name || !ltps || conducted === 0) return;
      if (!['L', 'T', 'P', 'S'].includes(ltps)) return;
      if (!subjectMap[name]) subjectMap[name] = { name, L:[0,0],T:[0,0],P:[0,0],S:[0,0], hasL:false,hasT:false,hasP:false,hasS:false };
      subjectMap[name][ltps]        = [attended, conducted];
      subjectMap[name]['has' + ltps] = true;
    });

    return Object.values(subjectMap);
  }

  // ── Toast ─────────────────────────────────────────
  function showToast(msg, type) {
    const old = document.getElementById('klu-toast');
    if (old) old.remove();
    const t = document.createElement('div');
    t.id = 'klu-toast';
    t.textContent = msg;
    t.style.cssText = `
      position:fixed; bottom:90px; right:28px; z-index:999999;
      background:${type==='success'?'#0e111a':'#1a0a0a'};
      border:1px solid ${type==='success'?'#5b52ff':'#ff4560'};
      color:${type==='success'?'#e2e6f3':'#ff4560'};
      border-radius:100px; padding:9px 18px;
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      font-size:12px; font-weight:500;
      box-shadow:0 4px 16px rgba(0,0,0,0.3);`;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity 0.3s'; setTimeout(() => t.remove(), 300); }, 3000);
  }
})();
